﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13.4
@EndOfDesignText@
#DesignerProperty: Key: BooleanExample, DisplayName: Show Seconds, FieldType: Boolean, DefaultValue: True
#DesignerProperty: Key: TextColor, DisplayName: Text Color, FieldType: Color, DefaultValue: 0xFFFFFFFF, Description: Text color

Sub Class_Globals
	Private mEventName As String 'ignore
	Private mCallBack As Object 'ignore
	Public mBase As B4XView
	Private xui As XUI 'ignore
	Public Tag As Object
	Private pnlWrapper As Panel
	Private pnlBottom As Panel
	Private vBitmap As ImageView
	Private lblText As Label
	Private lstEvent As List
	Type Events (color As Int, eventName As String, date As Long)
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

'Base type must be Object
Public Sub DesignerCreateView (Base As Object, lbl As Label, Props As Map)
	mBase = Base
    Tag = mBase.Tag
    mBase.Tag = Me 
  	Dim clr As Int = xui.PaintOrColorToColor(Props.Get("TextColor")) 'Example of getting a color value from Props
	lstEvent.Initialize
	vBitmap.Initialize("")
	vBitmap.Gravity = Gravity.CENTER
	
	pnlWrapper.Initialize("nplWrapper")		
	mBase.AddView(pnlWrapper, 0,0,mBase.Width,mBase.Height)
	
	lblText.Initialize("")
	pnlWrapper.AddView(lblText, 0, 0, pnlWrapper.Width, pnlWrapper.Height - 10dip)
	lblText.Text = 15
	lblText.Gravity = Gravity.CENTER_HORIZONTAL + Gravity.CENTER_VERTICAL
	
	pnlWrapper.AddView(vBitmap, 0, 0, pnlWrapper.Width, pnlWrapper.Height - 10dip)
	vBitmap.Visible = False
	
	pnlBottom.Initialize("")
	pnlWrapper.AddView(pnlBottom, 0,lblText.Height, pnlWrapper.Width, 10dip)
	
End Sub

Sub DrawEventSymbol
	pnlBottom.RemoveAllViews
	
	Dim positionX As Int = 0
	For i=0 To lstEvent.Size - 1
		Dim event As Events = lstEvent.Get(i)
		Dim lbl As Label
		lbl.Initialize("")
		lbl.As(B4XView).SetColorAndBorder(event.color, 0dip, Colors.White, 3dip)
		pnlBottom.AddView(lbl, positionX, 0, 6dip, 6dip)
		positionX = positionX + 8dip
	Next
		
	' Cacula to put center position
	pnlBottom.Width = (5dip * lstEvent.Size) + 8dip
	pnlBottom.Left= (pnlWrapper.Width - pnlBottom.Width) / 2
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
  
End Sub

Public Sub setText(value As String)
	lblText.Text = value
End Sub

Public Sub AddEvent(color As Int, eventName As String, date As Long)
	Dim event As Events
	event.Initialize
	event.color = color
	event.eventName = eventName
	event.date = date
	lstEvent.Add(event)	
	
	DrawEventSymbol
End Sub

Public Sub setBitMap(bitmap As B4XBitmap)
	vBitmap.Visible = True
	lblText.Visible = False
	vBitmap.Bitmap = bitmap	
	
End Sub
