﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

'Ctrl + click to export as zip: ide://run?File=%B4X%\Zipper.jar&Args=%PROJECT_NAME%.zip

Sub Class_Globals
	Private Root As B4XView
	Private xui As XUI
	Private CalendarBox1 As CalendarBox
	Private CalendarBox2 As CalendarBox
End Sub

Public Sub Initialize
'	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("layout_calendar")
	
	'CalendarBox1.AddEvent(Colors.ARGB(255,37, 150, 190), "Buy cookies", DateTime.Now)
	'CalendarBox1.AddEvent(Colors.ARGB(255,84, 119, 146), "Buy books", DateTime.Now)
	'CalendarBox1.AddEvent(Colors.ARGB(255,250, 185, 91), "Buy cards", DateTime.Now)
	
	'Dim b As B4XBitmap=LoadBitmapResize(File.DirAssets,"airplane.png", 20dip, 20dip, True)  'resizes the image
	'CalendarBox2.BitMap = b
End Sub

'You can see the list of page related events in the B4XPagesManager object. The event name is B4XPage.

Private Sub Button1_Click
	xui.MsgboxAsync("Hello world!", "B4X")
End Sub