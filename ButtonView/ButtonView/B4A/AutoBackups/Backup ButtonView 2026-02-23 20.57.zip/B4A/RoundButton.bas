﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13.4
@EndOfDesignText@
#DesignerProperty: Key: BooleanExample, DisplayName: Show Seconds, FieldType: Boolean, DefaultValue: True
#DesignerProperty: Key: TextColor, DisplayName: Text Color, FieldType: Color, DefaultValue: 0xFFFFFFFF, Description: Text color

Sub Class_Globals
	Private mEventName As String 'ignore
	Private mCallBack As Object 'ignore
	Public mBase As B4XView
	Private xui As XUI 'ignore
	Public Tag As Object
	Private imvIcon As Label
	Private lblText As Label
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

'Base type must be Object
Public Sub DesignerCreateView (Base As Object, lbl As Label, Props As Map)
	mBase = Base
    Tag = mBase.Tag
    mBase.Tag = Me 
  	Dim clr As Int = xui.PaintOrColorToColor(Props.Get("TextColor"))
	
	imvIcon.Initialize("")
	mBase.AddView(imvIcon, 0, 0, 30dip, 30dip)
	imvIcon.TextSize = 22
	imvIcon.Gravity = Gravity.CENTER_HORIZONTAL + Gravity.CENTER_VERTICAL
	imvIcon.TextColor = Colors.Blue
	
	lblText.Initialize("")
	mBase.AddView(lblText, 30dip, 0, mBase.Width - 30dip, 30dip)
	
	mBase.SetColorAndBorder(Colors.Transparent, 1dip, Colors.Blue, 8dip)
	
	lblText.Text = "Round Button"
	lblText.Gravity = Gravity.LEFT + Gravity.CENTER
	lblText.TextColor = Colors.Blue
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
  
End Sub

Public Sub SetFont(value As Typeface)
	imvIcon.Typeface = value
End Sub

Public Sub SetIcon(value As String)
	imvIcon.Text = value
End Sub