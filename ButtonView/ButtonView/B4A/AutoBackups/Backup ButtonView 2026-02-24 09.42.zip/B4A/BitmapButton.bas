﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13.4
@EndOfDesignText@
#DesignerProperty: Key: BooleanExample, DisplayName: Show Seconds, FieldType: Boolean, DefaultValue: True
#DesignerProperty: Key: TextColor, DisplayName: Text Color, FieldType: Color, DefaultValue: 0xFFFFFFFF, Description: Text color

Sub Class_Globals
	Private mEventName As String 'ignore
	Private mCallBack As Object 'ignore
	Public mBase As B4XView
	Private xui As XUI 'ignore
	Public Tag As Object
	Private pnlBgButton As Panel
	Private imvIcon As Label
	Private bm As BitmapCreator
	Private ico As B4XBitmap
	Private lblText As Label
	Private bgColor As Int = Colors.ARGB(255,156, 207, 255)
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

'Base type must be Object
Public Sub DesignerCreateView (Base As Object, lbl As Label, Props As Map)
	mBase = Base
    Tag = mBase.Tag
    mBase.Tag = Me 
  	Dim clr As Int = xui.PaintOrColorToColor(Props.Get("TextColor"))
	
	pnlBgButton.Initialize("")
	
	Dim width As Int = mBase.Width
	Dim height As Int = width
	Dim left As Int = (mBase.Width - width) / 2
	Dim radius As Int = (mBase.Width / 2) - 5dip
	
	mBase.AddView(pnlBgButton, left, 0dip, width, height)
	pnlBgButton.As(B4XView).SetColorAndBorder(bgColor, 0dip, Colors.DarkGray, radius)
	
	imvIcon.Initialize("")
	pnlBgButton.AddView(imvIcon, 5dip, 5dip, width - 10dip, height - 10dip)
	
	ico = LoadBitmapResize(File.DirAssets, "icons8-photo-94.png", 40dip, 40dip, False)
	
	bm.Initialize( width - 10dip, height - 10dip)
	bm.DrawBitmap(ico, bm.TargetRect, False)
	imvIcon.SetBackgroundImage(bm.Bitmap)
	
	lblText.Initialize("")
	lblText.Text = "Colors"
	mBase.AddView(lblText, 0, height + 3dip, width, 20dip)
	lblText.TextSize = 12
	lblText.Gravity = Gravity.CENTER_HORIZONTAL + Gravity.CENTER_VERTICAL
	
	mBase.Height = height + 25dip
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
  
End Sub